package com.gbox.emulator

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(this@MainActivity), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("goBack()") { if (it != "true") finish() }
    }
}

class Bridge(private val ctx: Context) {
    @JavascriptInterface
    fun getApps(): String {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val arr = JSONArray()
        pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .forEach { ri ->
                val out = ByteArrayOutputStream()
                ri.loadIcon(pm).toBitmap(72, 72).compress(Bitmap.CompressFormat.PNG, 100, out)
                arr.put(JSONObject()
                    .put("l", ri.loadLabel(pm).toString())
                    .put("p", ri.activityInfo.packageName)
                    .put("g", ri.activityInfo.applicationInfo.let { it.category == ApplicationInfo.CATEGORY_GAME || (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0 })
                    .put("i", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)))
            }
        return arr.toString()
    }

    @JavascriptInterface
    fun launch(pkg: String) {
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
    }

    @JavascriptInterface
    fun getInfo(): String {
        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val st = StatFs(Environment.getDataDirectory().path)
        val bat = ctx.getSystemService(BatteryManager::class.java)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return JSONObject()
            .put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
            .put("android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            .put("abi", Build.SUPPORTED_ABIS.joinToString(", "))
            .put("cores", Runtime.getRuntime().availableProcessors())
            .put("ramFree", mi.availMem).put("ramTotal", mi.totalMem)
            .put("storFree", st.availableBytes).put("storTotal", st.totalBytes)
            .put("battery", bat).toString()
    }

    @JavascriptInterface
    fun openTool(key: String) {
        val action = when (key) {
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "dev" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        try { ctx.startActivity(Intent(action)) }
        catch (e: Exception) { ctx.startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    @JavascriptInterface
    fun getCompat(): String {
        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val v = ctx.packageManager.systemAvailableFeatures
            .firstOrNull { it.name == "android.hardware.vulkan.version" }?.version ?: 0
        val vk = if (v == 0) 0.0 else (v shr 22) + ((v shr 12) and 0x3ff) / 10.0
        return JSONObject()
            .put("arm64", Build.SUPPORTED_64_BIT_ABIS.contains("arm64-v8a"))
            .put("api", Build.VERSION.SDK_INT).put("ram", mi.totalMem).put("vk", vk).toString()
    }

    private fun cdir() = File(ctx.filesDir, "containers").apply { mkdirs() }
    private fun safe(n: String) = n.replace(Regex("[^A-Za-z0-9_-]"), "_").take(32)

    @JavascriptInterface
    fun listContainers(): String {
        val arr = JSONArray()
        cdir().listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.forEach { d ->
            val f = File(d, "config.json")
            arr.put(if (f.exists()) JSONObject(f.readText())
                else JSONObject().put("name", d.name).put("res", "?").put("ram", "?").put("profile", "?"))
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun createContainer(name: String, res: String, ram: String, profile: String) {
        val d = File(cdir(), safe(name))
        File(d, "drive_c").mkdirs()
        File(d, "config.json").writeText(JSONObject().put("name", safe(name))
            .put("res", res).put("ram", ram).put("profile", profile).toString())
    }

    @JavascriptInterface
    fun deleteContainer(name: String) { File(cdir(), safe(name)).deleteRecursively() }
}
