plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.gbox.emulator"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.gbox.emulator"
        minSdk = 26; targetSdk = 34
        versionCode = 1; versionName = "Beta 0.4"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1") }
